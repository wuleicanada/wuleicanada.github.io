import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;

public class FillForm {

    private static final String DATE_SENT_DAU = "Sep 20, 2025";
    private static final String DATE_SENT_SBT = "Jul 25, 2025";
    private static final String DELIVERY_METHOD_DAU = "Courier";
    private static final String DELIVERY_METHOD_SBT = "Portal";

    private static class DocumentData {
        String number, description, date, pages;

        public DocumentData(String number, String description, String date, String pages) {
            this.number = number;
            this.description = description;
            this.date = date;
            this.pages = pages;
        }
    }

    public static void main(String[] args) {
        List<DocumentData> allDocs = populateDocumentData();
        List<InputStream> filledPages = new ArrayList<>();

        try {
            // Create Page 1
            try (PDDocument doc = PDDocument.load(new File("Form 5.pdf"))) {
                PDAcroForm form = doc.getDocumentCatalog().getAcroForm();
                fillHeader(form);
                for (int i = 0; i < 11; i++) {
                    fillRow(form, i + 1, allDocs.get(i), "page1");
                }
                doc.removePage(3);
                doc.removePage(1);
                doc.removePage(0);
                doc.setAllSecurityToBeRemoved(true);
                form.flatten();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                doc.save(baos);
                filledPages.add(new ByteArrayInputStream(baos.toByteArray()));
            }

            // Create subsequent pages
            int docIndex = 11;
            while (docIndex < allDocs.size()) {
                try (PDDocument doc = PDDocument.load(new File("Form 5.pdf"))) {
                    PDAcroForm form = doc.getDocumentCatalog().getAcroForm();
                    int rowsOnThisPage = Math.min(11, allDocs.size() - docIndex);
                    for (int i = 0; i < rowsOnThisPage; i++) {
                        fillRow(form, i + 12, allDocs.get(docIndex + i), "page2");
                    }
                    doc.removePage(2);
                    doc.removePage(1);
                    doc.removePage(0);
                    doc.setAllSecurityToBeRemoved(true);
                    form.flatten();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    doc.save(baos);
                    filledPages.add(new ByteArrayInputStream(baos.toByteArray()));
                    docIndex += rowsOnThisPage;
                }
            }

            PDFMergerUtility pdfMerger = new PDFMergerUtility();
            pdfMerger.addSources(filledPages);
            pdfMerger.setDestinationFileName("Form 5 - Jocelyn Dulliyao - Updated.pdf");
            pdfMerger.mergeDocuments(null);

            System.out.println("PDF created successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            for(InputStream in : filledPages) {
                try { in.close(); } catch (IOException e) { e.printStackTrace(); }
            }
        }
    }
    
    private static void fillHeader(PDAcroForm form) throws IOException {
        setField(form, "form1[0].page1[0].File_number[0].FileNumber[0]", "2504-02925");
        setField(form, "form1[0].page1[0].AppellantName[0]", "Jocelyn Dulliyao");
        setField(form, "form1[0].page1[0].AppellantBirthDate[0]", "December 20, 1973");
        setField(form, "form1[0].page1[0].SBTHearingDate[0]", "October 30, 2025");
        setField(form, "form1[0].page1[0].LegalRepName[0]", "Imtiaz Hosein");
        setField(form, "form1[0].page1[0].SenderName[0]", "Sarah Wang");
        setField(form, "form1[0].page1[0].SenderPhoneNumber[0]", "416-203-1115");
        setField(form, "form1[0].page1[0].SenderFaxNumber[0]", "416-203-7775");
    }

    private static void fillRow(PDAcroForm form, int rowNum, DocumentData data, String pageName) throws IOException {
        String tablePrefix = pageName.equals("page1") ? "Table1" : "Table2";
        String fullRowNum = String.valueOf(rowNum);

        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].DocNumber%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), data.number);
        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].DocDesc%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), data.description);
        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].DocDate%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), data.date);
        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].PageNos%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), data.pages);
        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].SentDAU%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), DATE_SENT_DAU);
        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].SentSBT%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), DATE_SENT_SBT);
        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].HowDeliveredDAU%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), DELIVERY_METHOD_DAU);
        setField(form, String.format("form1[0].%s[0].%s[0].Row%s[0].HowDeliveredSBT%s[0]", pageName, tablePrefix, fullRowNum, fullRowNum), DELIVERY_METHOD_SBT);
    }

    private static void setField(PDAcroForm form, String fieldName, String value) throws IOException {
        PDField field = form.getField(fieldName);
        if (field != null) {
            // Apply auto-sizing to fields that might have wrapping text.
            if (fieldName.contains("DocDesc") || fieldName.contains("DocDate") || fieldName.contains("SentDAU") || fieldName.contains("SentSBT")) {
                COSDictionary fieldDict = field.getCOSObject();
                String daString = fieldDict.getString(COSName.DA);

                if (daString != null) {
                    String newDaString = daString.replaceAll("(\\d*\\.?\\d+)\\s+Tf", "0 Tf");
                    fieldDict.setString(COSName.DA, newDaString);
                }
            }
            field.setValue(value);
        }
    }

    private static List<DocumentData> populateDocumentData() {
        List<DocumentData> allDocs = new ArrayList<>();
        allDocs.add(new DocumentData("1", "MVA Report and Police File", "May 25, 2023", "11"));
        allDocs.add(new DocumentData("2", "Injury Photos", "Jan 31, 2023", "9"));
        allDocs.add(new DocumentData("3", "Ambulance Call Report", "Nov 25, 2022", "6"));
        allDocs.add(new DocumentData("4", "Application for Catastrophic Determination (Criterion 4)", "Feb 4, 2024", "68"));
        allDocs.add(new DocumentData("5", "Application for Catastrophic Determination (Criterion 6-8)", "Jan 31, 2025", "159"));
        allDocs.add(new DocumentData("6", "OCF-19 from Dr. Carly Rogenstein", "Jan 31, 2025", "6"));
        allDocs.add(new DocumentData("7", "Catastrophic Impairment Report by Gordon Cheung", "Apr 18, 2024", "21"));
        allDocs.add(new DocumentData("8", "MRI SPECT Medical Report of Dr. Yin-Hui Siow", "Oct 26, 2023", "3"));
        allDocs.add(new DocumentData("9", "Emergency Physician Assessment by Dr. Krishna", "Nov 26, 2022", "2"));
        allDocs.add(new DocumentData("10", "Hospital Records, North York General (11/25/19 - 12/9/22)", "Dec 09, 2022", "45"));
        allDocs.add(new DocumentData("11", "Hospital Records, North York General (12/9/22 - 04/03/24)", "Apr 03, 2024", "18"));
        allDocs.add(new DocumentData("12", "Letter - No Hospital Records between (07/23/24 - 04/03/25)", "Apr 03, 2025", "2"));
        allDocs.add(new DocumentData("13", "Hospital Records - Humber River (11/25/19 - 04/14/25)", "Apr 14, 2025", "34"));
        allDocs.add(new DocumentData("14", "Occupational Therapy (OT) (OCF-18) Submission Letter", "Jan 5 2023", "3"));
        allDocs.add(new DocumentData("15", "OT Form 1 and Equipment Submission Letter", "Feb 14, 2023", "20"));
        allDocs.add(new DocumentData("16", "Referral Letter: Psychological Assessment and Treatment", "Feb 27, 2023", "3"));
        allDocs.add(new DocumentData("17", "OT Update Letter to Family Physician by Shelly Cohen", "Mar 7, 2023", "7"));
        allDocs.add(new DocumentData("18", "Functional Abilities Form from Employer", "Mar 31, 2023", "2"));
        allDocs.add(new DocumentData("19", "OT Functional Assessment Report by Shelly Cohen", "May 5, 2023", "57"));
        allDocs.add(new DocumentData("20", "OT Functional Assessment Report and Form 1", "May 5, 2023", "75"));
        allDocs.add(new DocumentData("21", "OT Equipment Submission Letter", "Jun 30, 2023", "12"));
        allDocs.add(new DocumentData("22", "OT Functional Cognitive Assessment Report", "Jul 27, 2023", "40"));
        allDocs.add(new DocumentData("23", "Psychological Assessment Report by Dr. Peter Waxer", "Aug 3, 2023", "12"));
        allDocs.add(new DocumentData("24", "OT Request for SPECT Scan & MRI Head Referral", "Sep 27, 2023", "34"));
        allDocs.add(new DocumentData("25", "OT Update Letter by Shelly Cohen", "Oct 5, 2023", "7"));
        allDocs.add(new DocumentData("26", "OT Update Letter #2 by Shelly Cohen", "Apr 23, 2024", "6"));
        allDocs.add(new DocumentData("27", "OT Update Letter #2 by Shelly Cohen", "May 1, 2024", "24"));
        allDocs.add(new DocumentData("28", "Social Work Update Letter from Critical Trauma Therapy", "Jun 19, 2024", "13"));
        allDocs.add(new DocumentData("29", "Clinical Notes and Records of Dr. Atwal (11/25/19--5/12/23)", "May 12, 2023", "104"));
        allDocs.add(new DocumentData("30", "Clinical Notes and Records of Dr. Atwal (03/25/24-10/26/24)", "Oct 26, 2024", "43"));
        allDocs.add(new DocumentData("31", "Clinical Notes and Records of Dr. Atwal (08/26/24-02/05/25)", "Feb 5, 2025", "103"));
        allDocs.add(new DocumentData("32", "Records from Mackenzie Medical (enrol-02/08/23)", "Feb 8, 2023", "15"));
        allDocs.add(new DocumentData("33", "Clinical Notes and Records of Dr. Katyal (enrol-06/14/23)", "Jun 14, 2023", "7"));
        allDocs.add(new DocumentData("34", "Medical Records, Chiropractor (11/25/19-04/29/)", "Apr 29, 2024", "73"));
        allDocs.add(new DocumentData("35", "CNRs of Innovative OT(enrollment date-11/20/23)", "Nov 20, 2023", "210"));
        allDocs.add(new DocumentData("36", "CNRs of Innovative OT(11/20/23-03/29/24)", "Mar 29, 2024", "6"));
        allDocs.add(new DocumentData("37", "CNRs of Innovative OT (03/29/24-02/07/25)", "Feb 7, 2025", "44"));
        allDocs.add(new DocumentData("38", "CNRs of Critical Trauma Therapy (enrol-03/27/24)", "Mar 27, 2024", "16"));
        allDocs.add(new DocumentData("39", "CNRs of Critical Trauma Therapy (03/29/24-01/31/25)", "Jan 31, 2025", "19"));
        allDocs.add(new DocumentData("40", "CNRs of Dr. Tyler Bao (11/25/19-02/25/25)", "Feb 25, 2025", "9"));
        allDocs.add(new DocumentData("41", "CNRs of GSH Medical (11/25/19-09/06/24)", "Sep 6, 2024", "21"));
        allDocs.add(new DocumentData("42", "CNRs of Dr. Segal from GSH Medical (08/26/24-01/31/25)", "Jan 31, 2025", "18"));
        allDocs.add(new DocumentData("43", "CNRs of Canadian Active Rehab (11/25/19-04/01/24)", "Apr 1, 2025", "207"));
        allDocs.add(new DocumentData("44", "CNRs of Canadian Active Rehab (01/01/24-03/28/25)", "Mar 28, 2025", "179"));
        allDocs.add(new DocumentData("45", "CNRs of Ms. Zokaei (11/25/19-04/01/25)", "Apr 1, 2025", "3"));
        allDocs.add(new DocumentData("46", "CNRs of Dermatology Centre (11/25/19-04/01/25)", "Apr 1, 2025", "16"));
        allDocs.add(new DocumentData("47", "Disability Certificate (OCF-3) by Dr. Atwal", "Feb 27, 2023", "6"));
        allDocs.add(new DocumentData("48", "Disability Certificate (OCF-3) by Dr. Atwal", "Oct 3, 2023", "6"));
        allDocs.add(new DocumentData("49", "OHIP Summary (11/25/19-03/08/23)", "Mar 8, 2023", "32"));
        allDocs.add(new DocumentData("50", "OHIP Summary (03/08/23-04/25/24)", "Apr 25, 2024", "13"));
        allDocs.add(new DocumentData("51", "OHIP Summary (04/25/24-01/29/25)", "Jan 29, 2025", "20"));
        allDocs.add(new DocumentData("52", "Medication History, Shoppers Drug Mart(11/25/19-12/09/22)", "Dec 9, 2022", "6"));
        allDocs.add(new DocumentData("53", "Medication History, Shoppers Drug Mart(03/25/24-01/17/25)", "Jan 17, 2025", "7"));
        allDocs.add(new DocumentData("54", "Modified Duties Offer from Employer", "Jan 31, 2023", "1"));
        allDocs.add(new DocumentData("55", "Earnings Statement (Sept-Dec 2022)", "Jan 31, 2023", "7"));
        allDocs.add(new DocumentData("56", "Employer's Confirmation Form (OCF-2)", "Dec 12, 2023", "3"));
        allDocs.add(new DocumentData("57", "Entire Employment File, Johnvince Foods", "May 11, 2023", "37"));
        allDocs.add(new DocumentData("58", "Short Term Disability Policy Instructions on Modified Duty", "Nov 30, 2022", "3"));
        allDocs.add(new DocumentData("59", "Email b/w Appellant and Employer re: Modified Duties", "Jan 25, 2023", "5"));
        allDocs.add(new DocumentData("60", "Green Shield Canada Claims History (11/25/19-12/09/22)", "Dec 9, 2022", "31"));
        allDocs.add(new DocumentData("61", "STD Payment (01/13/23-04/06/23)", "Apr 6, 2023", "1"));
        allDocs.add(new DocumentData("62", "Entire STD file from Acclaim Ability Management", "Feb 7, 2023", "32"));
        allDocs.add(new DocumentData("63", "Last email of STD showing STD ended", "Mar 24, 2023", "1"));
        allDocs.add(new DocumentData("64", "Green Shield Canada (12/09/22-01/09/25)", "Jan 9, 2025", "34"));
        allDocs.add(new DocumentData("65", "Income Tax Returns (2019-2021)", "Jan 31, 2023", "155"));
        allDocs.add(new DocumentData("66", "Income Tax Return for 2022", "Mar 27, 2023", "50"));
        allDocs.add(new DocumentData("67", "Income Tax Return 2023", "Apr 4, 2024", "52"));
        allDocs.add(new DocumentData("68", "Income Tax Return 2024", "Apr 25, 2025", "39"));
        allDocs.add(new DocumentData("69", "ODSP Denial Letter", "Feb 4, 2025", "1"));
        allDocs.add(new DocumentData("70", "ODSP Denial on Internal Review", "Mar 25, 2025", "1"));
        allDocs.add(new DocumentData("71", "ODSP Request for Internal Review", "Mar 7, 2025", "2"));
        return allDocs;
    }
}
